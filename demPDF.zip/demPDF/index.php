<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đếm PDF + DOCX</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
body{
    background:#f5f5f5;
    font-family:Arial,sans-serif;
    margin:0;
}

.container{
    max-width:1200px;
    margin:40px auto;
    background:#fff;
    padding:30px;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,.1);
}

h1{
    text-align:center;
    margin-bottom:5px;
}

.sub{
    text-align:center;
    color:#777;
    margin-bottom:20px;
}

.actions{
    display:flex;
    gap:10px;
    margin-bottom:15px;
    flex-wrap:wrap;
}

button,.btn{
    padding:10px 15px;
    background:#007bff;
    color:#fff;
    border-radius:8px;
    text-decoration:none;
    border:none;
    cursor:pointer;
}

button:hover,.btn:hover{
    background:#0056b3;
}

input[type="file"]{
    flex:1;
}

table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:10px;
    border-bottom:1px solid #ddd;
    text-align:center;
}

td:nth-child(2){
    text-align:left;
}

thead{
    background:#f5f5f5;
}

tbody tr:hover{
    background:#f9f9f9;
}

tfoot{
    background:#fafafa;
    font-weight:bold;
}

.copies-input{
    width:70px;
    padding:5px;
    text-align:center;
}
</style>
<link rel="icon" href="/logo.png" sizes="32x32" />
</head>

<body>

<div class="container">

<center>
    <h1>THIÊN KIM AI</h1>
<h3>CÔNG CỤ TÍNH TIỀN IN PDF + DOCX</h3>
</center>
<div class="sub">Realtime xử lý từng file, đơn giá mặc định 450đ/tờ. Chọn [Chọn Tệp] để chọn những file cần in và tính tiền</div>

<div class="actions">
    <input type="file" id="fileInput" multiple accept=".pdf,.docx">
    <label style="display:flex;align-items:center;gap:8px;font-weight:600;white-space:nowrap;">
        Đơn giá/tờ (đ)
        <input type="number" id="unitPrice" min="0" step="50" value="450" style="width:100px;padding:9px;border:1px solid #ccc;border-radius:8px;">
    </label>
    <button onclick="clearTable()">Refresh</button>
    <button onclick="exportExcel()">Xuất Excel</button>
</div>

<table>
    <thead>
        <tr>
            <th>STT</th>
            <th>Tên file</th>
            <th>Số bộ</th>
            <th>In 1 mặt</th>
            <th>In 2 mặt</th>
            <th>Giá 1 mặt</th>
            <th>Giá 2 mặt</th>
        </tr>
    </thead>

    <tbody id="tbody"></tbody>

    <tfoot>
        <tr id="totalRow">
            <td colspan="3">Tổng</td>
            <td>0</td>
            <td>0</td>
            <td>0 đ</td>
            <td>0 đ</td>
        </tr>
    </tfoot>
</table>

</div>

<script>
const input = document.getElementById('fileInput');
const tbody = document.getElementById('tbody');
const unitPriceInput = document.getElementById('unitPrice');

let dataList = [];
let stt = 1;

function formatMoney(num){
    return num.toLocaleString('vi-VN') + ' đ';
}

function getUnitPrice(){
    const value = Number(unitPriceInput.value);
    return Number.isFinite(value) && value >= 0 ? value : 0;
}

function recalculateRow(index){

    const item = dataList[index];

    const oneSide = item.pages * item.copies;
    const twoSide = Math.ceil(item.pages / 2) * item.copies;


/**
 * 
 *  Đơn giá 1 tờ
 *    | ở đây: 450 đ/tờ bất kể 1 hay 2 mặt 
 *
 **/ 
    const unitPrice = getUnitPrice();
    const oneSidePrice = oneSide * unitPrice;
    const twoSidePrice = twoSide * unitPrice;

    item.oneSide = oneSide;
    item.twoSide = twoSide;
    item.oneSidePrice = oneSidePrice;
    item.twoSidePrice = twoSidePrice;

    const row = item.row;

    row.cells[3].innerText = oneSide;
    row.cells[4].innerText = twoSide;
    row.cells[5].innerText = formatMoney(oneSidePrice);
    row.cells[6].innerText = formatMoney(twoSidePrice);

    updateTotal();
}

function updateTotal(){

    let totalOneSide = 0;
    let totalTwoSide = 0;
    let totalOneSidePrice = 0;
    let totalTwoSidePrice = 0;

    dataList.forEach(item => {

        totalOneSide += item.oneSide || 0;
        totalTwoSide += item.twoSide || 0;
        totalOneSidePrice += item.oneSidePrice || 0;
        totalTwoSidePrice += item.twoSidePrice || 0;

    });

    const cells = document.querySelectorAll('#totalRow td');

    cells[1].innerText = totalOneSide;
    cells[2].innerText = totalTwoSide;
    cells[3].innerText = formatMoney(totalOneSidePrice);
    cells[4].innerText = formatMoney(totalTwoSidePrice);
}

unitPriceInput.addEventListener('input', function(){
    dataList.forEach((item, index) => recalculateRow(index));
});

input.addEventListener('change', async function(){

    for(const file of this.files){

        const row = tbody.insertRow();

        row.innerHTML = `
            <td>${stt++}</td>
            <td>${file.name}</td>
            <td>
                <input
                    type="number"
                    min="1"
                    value="1"
                    class="copies-input">
            </td>
            <td>Đang xử lý...</td>
            <td>...</td>
            <td>...</td>
            <td>...</td>
        `;

        const formData = new FormData();
        formData.append('file', file);

        try{

            const res = await fetch(new URL('api-count.php', window.location.href), {
                method:'POST',
                body:formData
            });
            const responseText = await res.text();
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (_) {
                throw new Error('API không trả JSON. Kiểm tra lỗi PHP/đường dẫn api-count.php. Phản hồi: ' + responseText.slice(0, 250));
            }
            if (!res.ok || data.success === false) {
                throw new Error(data.error || ('Máy chủ trả HTTP ' + res.status));
            }

            const item = {
                name:file.name,
                pages:parseInt(data.pages, 10) || 0,
                copies:1,
                row:row
            };

            dataList.push(item);

            const index = dataList.length - 1;

            const copiesInput = row.querySelector('.copies-input');

            copiesInput.addEventListener('input', function(){

                let val = parseInt(this.value);

                if(isNaN(val) || val < 1){
                    val = 1;
                }

                this.value = val;

                dataList[index].copies = val;

                recalculateRow(index);
            });

            recalculateRow(index);

        }catch(e){
            console.error('Lỗi đếm file:', e);
            row.cells[3].innerText = 'Lỗi: ' + (e.message || 'Không xử lý được file');
            row.cells[4].innerText = '-';
            row.cells[5].innerText = '-';
            row.cells[6].innerText = '-';
        }

    }

    this.value = '';
});

function clearTable(){

    tbody.innerHTML = '';

    dataList = [];
    stt = 1;

    updateTotal();
}

function exportExcel(){

    if(dataList.length === 0){
        alert("Chưa có dữ liệu!");
        return;
    }

    let content =
`STT\tTên file\tSố bộ\tIn 1 mặt\tIn 2 mặt\tGiá 1 mặt\tGiá 2 mặt
`;

    dataList.forEach((item,i)=>{

        content +=
`${i+1}\t${item.name}\t${item.copies}\t${item.oneSide}\t${item.twoSide}\t${item.oneSidePrice}\t${item.twoSidePrice}
`;

    });

    const blob = new Blob(
        [content],
        {type:"application/vnd.ms-excel;charset=utf-8;"}
    );

    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'ketqua.xls';
    a.click();

    URL.revokeObjectURL(url);
}
</script>

</body>
</html>