<?php
// Compatible with older PHP versions commonly bundled with USBWebserver.
header('Content-Type: application/json; charset=utf-8');

function api_respond($data, $status) {
    if (function_exists('http_response_code')) {
        http_response_code($status);
    } else {
        $texts = array(400 => 'Bad Request', 405 => 'Method Not Allowed', 422 => 'Unprocessable Entity', 500 => 'Internal Server Error');
        header('HTTP/1.1 ' . $status . ' ' . (isset($texts[$status]) ? $texts[$status] : 'Error'));
    }
    echo json_encode($data);
    exit;
}

if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    api_respond(array('success' => false, 'error' => 'Chỉ chấp nhận POST.'), 405);
}

if (!isset($_FILES['file'])) {
    api_respond(array('success' => false, 'error' => 'Không nhận được file tải lên. Kiểm tra post_max_size và upload_max_filesize.'), 400);
}

$upload = $_FILES['file'];
$uploadError = isset($upload['error']) ? $upload['error'] : UPLOAD_ERR_NO_FILE;
if ($uploadError !== UPLOAD_ERR_OK) {
    $uploadErrors = array(
        UPLOAD_ERR_INI_SIZE => 'File vượt quá upload_max_filesize trong php.ini.',
        UPLOAD_ERR_FORM_SIZE => 'File vượt quá giới hạn cho phép.',
        UPLOAD_ERR_PARTIAL => 'File chỉ được tải lên một phần.',
        UPLOAD_ERR_NO_FILE => 'Chưa có file được tải lên.',
        UPLOAD_ERR_NO_TMP_DIR => 'Máy chủ thiếu thư mục tạm.',
        UPLOAD_ERR_CANT_WRITE => 'Máy chủ không ghi được file tạm.',
        UPLOAD_ERR_EXTENSION => 'Một extension PHP đã chặn việc tải file.'
    );
    $message = isset($uploadErrors[$uploadError]) ? $uploadErrors[$uploadError] : 'Lỗi tải file không xác định.';
    api_respond(array('success' => false, 'error' => $message), 400);
}

$tmp = $upload['tmp_name'];
$name = $upload['name'];
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!is_readable($tmp)) {
    api_respond(array('success' => false, 'error' => 'Không đọc được file tải lên.'), 400);
}

try {
    $pages = 0;
    if ($ext === 'pdf') {
        // Do not load Smalot\PdfParser here: the copy installed on this
        // USBWebserver uses syntax unsupported by its bundled PHP version.
        // This lightweight fallback counts visible /Type /Page objects.
        $content = @file_get_contents($tmp);
        if ($content === false || $content === '') {
            api_respond(array('success' => false, 'error' => 'Không đọc được nội dung PDF.'), 400);
        }
        if (strpos($content, '%PDF-') !== 0) {
            api_respond(array('success' => false, 'error' => 'File không có chữ ký PDF hợp lệ.'), 400);
        }
        preg_match_all('~/Type\s*/Page(?!s)\b~', $content, $matches);
        $pages = count($matches[0]);
        if ($pages < 1) {
            api_respond(array('success' => false, 'error' => 'Không đếm được trang PDF bằng bộ đếm tương thích. PDF có thể dùng cấu trúc nén/object streams; cần nâng PHP hoặc dùng thư viện PDF Parser tương thích.'), 422);
        }
    } elseif ($ext === 'docx') {
        if (!class_exists('ZipArchive')) {
            api_respond(array('success' => false, 'error' => 'PHP chưa bật extension ZIP (ZipArchive). Bật extension zip trong php.ini rồi khởi động lại USBWebserver.'), 500);
        }
        $zip = new ZipArchive();
        if ($zip->open($tmp) !== true) {
            api_respond(array('success' => false, 'error' => 'File DOCX không hợp lệ hoặc không mở được.'), 400);
        }
        $xml = $zip->getFromName('docProps/app.xml');
        $zip->close();
        if ($xml !== false && preg_match('~<Pages>\s*(\d+)\s*</Pages>~i', $xml, $matches)) {
            $pages = (int)$matches[1];
        } else {
            api_respond(array('success' => false, 'error' => 'DOCX này không có metadata số trang. Hãy mở và lưu lại bằng Word/LibreOffice; metadata DOCX có thể không cập nhật số trang.'), 422);
        }
    } else {
        api_respond(array('success' => false, 'error' => 'Chỉ hỗ trợ file PDF và DOCX.'), 400);
    }
    api_respond(array('success' => true, 'name' => $name, 'pages' => $pages), 200);
} catch (Exception $e) {
    error_log('api-count.php: ' . $e->getMessage());
    api_respond(array('success' => false, 'error' => 'Lỗi xử lý file: ' . $e->getMessage()), 500);
}
?>
