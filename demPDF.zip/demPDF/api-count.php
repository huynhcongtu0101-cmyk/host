<?php

require __DIR__ . '/lib/pdfparser/autoload.php';
use Smalot\PdfParser\Parser;

function countPdfPages($file) {
    try {
        $parser = new Parser();
        $pdf = $parser->parseFile($file);
        return count($pdf->getPages());
    } catch (Exception $e) {}

    $content = @file_get_contents($file);
    preg_match_all("/\/Type\s*\/Page[^s]/", $content, $matches);
    return count($matches[0]);
}

function countDocxPages($file) {
    $zip = new ZipArchive;
    if ($zip->open($file) === TRUE) {
        if (($index = $zip->locateName('docProps/app.xml')) !== false) {
            $data = $zip->getFromIndex($index);
            preg_match('/<Pages>(\d+)<\/Pages>/', $data, $matches);
            return (int)($matches[1] ?? 0);
        }
        $zip->close();
    }
    return 0;
}

if (!isset($_FILES['file'])) exit;

$tmp = $_FILES['file']['tmp_name'];
$name = $_FILES['file']['name'];
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

$pages = 0;

if ($ext === 'pdf') $pages = countPdfPages($tmp);
if ($ext === 'docx') $pages = countDocxPages($tmp);

echo json_encode([
    'name' => $name,
    'pages' => $pages
]);